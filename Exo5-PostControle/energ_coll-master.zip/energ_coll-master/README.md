# Grille d'évaluation

## HTML
|Point|description|
|-----|-----------|
|4pts |qualité du code|
|4pts | layout fonctionnel|

## CSS
|Point|description|
|-----|-----------|
|4pts |qualité du code|
|2pts |nommage des classes|
|2pts |utilisation scss|
|2pts |utilisation 2 fonctions scss|

## SVG
|Point|description|
|-----|-----------|
|2pts |utilisation sprite|
